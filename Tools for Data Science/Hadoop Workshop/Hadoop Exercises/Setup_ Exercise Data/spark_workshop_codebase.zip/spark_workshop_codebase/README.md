#Intro to Apache Spark Workshop Codebase

##Description
Includes examples, samples, exercise modules and a playground module for people to reference and use when taking the Intro to Apache Spark workshop 