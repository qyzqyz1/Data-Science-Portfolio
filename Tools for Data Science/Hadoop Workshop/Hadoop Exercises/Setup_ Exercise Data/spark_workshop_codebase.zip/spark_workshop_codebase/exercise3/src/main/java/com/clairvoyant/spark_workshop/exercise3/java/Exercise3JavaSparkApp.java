package com.clairvoyant.spark_workshop.exercise3.java;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;


public class Exercise3JavaSparkApp {

    private static String BASE_DIR = "/user/cloudera/spark_data/company/";

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Exercise3JavaSparkApp").setMaster("yarn-client");
        JavaSparkContext sc = new JavaSparkContext(conf);
        SQLContext sqlContext = new HiveContext(sc);

        DataFrame addressDF = sqlContext.read().format("com.databricks.spark.csv")
                .option("delimiter", "\t")
                .load(BASE_DIR + "address.tsv")
                .toDF("address_id", "street", "city", "state", "zip_code", "country_code");

        DataFrame companyDF = sqlContext.read().format("com.databricks.spark.csv")
                .option("delimiter", "\t")
                .load(BASE_DIR + "company.tsv")
                .toDF("company_id", "name", "address_id");

        addressDF.show(10);
        addressDF.registerTempTable("addresses");

        companyDF.show(10);
        companyDF.registerTempTable("companies");


        // TODO: - Join the 2 data sets using the sqlContext.sql("") method (join the datasets on address_id) and save the data as a table in Hive (insert overwrite into the table)
        //sqlContext.sql("TO BE COMPLETED");

        // TODO: - Query the table from the previous setup and filter the result by those rows that have "AZ" set  as the state (again using the sqlContext.sql("") method)
        //sqlContext.sql("TO BE COMPLETED");

    }

}