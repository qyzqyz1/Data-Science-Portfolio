package com.clairvoyant.spark_workshop.exercise3.scala

import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkContext, SparkConf}


object Exercise3ScalaSparkApp {

  val BASE_DIR = "/user/cloudera/spark_data/company/"

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("Exercise3ScalaSparkApp").setMaster("yarn-client")
    val sc = new SparkContext(conf)
    val sqlContext = new HiveContext(sc)

    val addressDF = sqlContext.read.format("com.databricks.spark.csv")
      .option("delimiter", "\t")
      .load(BASE_DIR + "address.tsv")
      .toDF("address_id", "street", "city", "state", "zip_code", "country_code")

    val companyDF = sqlContext.read.format("com.databricks.spark.csv")
      .option("delimiter", "\t")
      .load(BASE_DIR + "company.tsv")
      .toDF("company_id", "name", "address_id")

    addressDF.show(10)
    addressDF.registerTempTable("addresses")

    companyDF.show(10)
    companyDF.registerTempTable("companies")

    // TODO: - Join the 2 data sets using the sqlContext.sql("") method (join the datasets on address_id) and save the data as a table in Hive (insert overwrite into the table)
    //sqlContext.sql("TO BE COMPLETED")

    // TODO: - Query the table from the previous setup and filter the result by those rows that have "AZ" set  as the state (again using the sqlContext.sql("") method)
    //sqlContext.sql("TO BE COMPLETED")

  }

}