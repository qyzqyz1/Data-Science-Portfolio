__author__ = 'Clairvoyant'

from pyspark import SparkConf, SparkContext
from pyspark.sql import HiveContext


BASE_DIR = "/user/cloudera/spark_data/company/"

if __name__ == "__main__":
    conf = SparkConf().setAppName("Exercise3PythonSparkApp").setMaster("yarn-client")
    sc = SparkContext(conf=conf)
    sqlContext = HiveContext(sc)

    addressDF = sqlContext.read.format("com.databricks.spark.csv") \
        .option("delimiter", "\t") \
        .load(BASE_DIR + "address.tsv") \
        .toDF("address_id", "street", "city", "state", "zip_code", "country_code")

    companyDF = sqlContext.read.format("com.databricks.spark.csv") \
        .option("delimiter", "\t") \
        .load(BASE_DIR + "company.tsv") \
        .toDF("company_id", "name", "address_id")

    addressDF.show(10)
    addressDF.registerTempTable("addresses")

    companyDF.show(10)
    companyDF.registerTempTable("companies")

    # TODO: - Join the 2 data sets using the sqlContext.sql("") method (join the datasets on address_id) and save the data as a table in Hive (insert overwrite into the table)
    #sqlContext.sql("TO BE COMPLETED")

    # TODO: - Query the table from the previous setup and filter the result by those rows that have "AZ" set  as the state (again using the sqlContext.sql("") method)
    #sqlContext.sql("TO BE COMPLETED")
