#Exercise 3 Module

##Running Code
###Runnnig Java
$ spark-submit --class com.clairvoyant.spark_workshop.exercise3.java.Exercise3JavaSparkApp com.clairvoyant.spark_workshop.exercise3-jar-with-dependencies.jar

###Running Python
$ spark-submit --repositories http://repo1.maven.org/maven2 --packages com.databricks:spark-csv_2.10:1.2.0 Exercise3PythonSparkApp.py

###Running Scala
$ spark-submit --class com.clairvoyant.spark_workshop.exercise3.scala.Exercise3ScalaSparkApp com.clairvoyant.spark_workshop.exercise3-jar-with-dependencies.jar