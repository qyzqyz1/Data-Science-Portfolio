#Exercise 1 Module

##Running Code
###Runnnig Java
$ spark-submit --class com.clairvoyant.spark_workshop.exercise1.java.Exercise1JavaSparkApp com.clairvoyant.spark_workshop.exercise1-jar-with-dependencies.jar

###Running Python
$ spark-submit Exercise1PythonSparkApp.py

###Running Scala
$ spark-submit --class com.clairvoyant.spark_workshop.exercise1.scala.Exercise1ScalaSparkApp com.clairvoyant.spark_workshop.exercise1-jar-with-dependencies.jar