#Exercise 2 Module

##Running Code
###Runnnig Java
$ spark-submit --class com.clairvoyant.spark_workshop.exercise2.java.Exercise2JavaSparkApp com.clairvoyant.spark_workshop.exercise2-jar-with-dependencies.jar

###Running Python
$ spark-submit Exercise2PythonSparkApp.py

###Running Scala
$ spark-submit --class com.clairvoyant.spark_workshop.exercise2.scala.Exercise2ScalaSparkApp com.clairvoyant.spark_workshop.exercise2-jar-with-dependencies.jar