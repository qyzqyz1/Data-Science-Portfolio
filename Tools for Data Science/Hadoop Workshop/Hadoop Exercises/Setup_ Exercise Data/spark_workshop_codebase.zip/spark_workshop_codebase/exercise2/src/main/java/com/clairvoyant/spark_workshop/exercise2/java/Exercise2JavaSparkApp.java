package com.clairvoyant.spark_workshop.exercise2.java;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.*;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Exercise2JavaSparkApp {

    private static String PATH_TO_FILE = "/user/cloudera/spark_data/logs/access.log";

    private static String ACCESS_LOG_REGEX= "^(\\S+) (\\S+) (\\S+) \\[(\\S+ \\S+ \\S+ \\S+ \\S+ \\S+)] \"(\\S+)\\s?(\\S+)?\\s?(\\S+)?\" (\\d{3}|-) (\\d+|-)\\s?\"?([^\"]*)\"?\\s?\"?([^\"]*)?\"?$";

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Exercise2JavaSparkApp").setMaster("yarn-client");
        JavaSparkContext sc = new JavaSparkContext(conf);
        SQLContext sqlContext = new HiveContext(sc);

        DataFrame rawAccessLogDF = sqlContext.read().text(PATH_TO_FILE);

        final Pattern pattern = Pattern.compile(ACCESS_LOG_REGEX);

        JavaRDD<Row> rdd = rawAccessLogDF.toJavaRDD().map(new Function<Row, Row>() {
            @Override
            public Row call(Row row) {
                Matcher matcher = pattern.matcher(row.getString(0));
                if (matcher.find()) {
                    return RowFactory.create(matcher.group(1), matcher.group(2), matcher.group(3), matcher.group(4), matcher.group(5), matcher.group(6), matcher.group(7), matcher.group(8), matcher.group(9), matcher.group(10), matcher.group(11));
                } else {
                    return RowFactory.create((Object) null);
                }
            }
        }).filter(new Function<Row, Boolean>() {
            @Override
            public Boolean call(Row row) {
                return row != null;
            }
        });

        StructField[] structFields = new StructField[]{
                new StructField("host", DataTypes.StringType, true, Metadata.empty()),
                new StructField("client_indentd", DataTypes.StringType, true, Metadata.empty()),
                new StructField("user_id", DataTypes.StringType, true, Metadata.empty()),
                new StructField("date_time", DataTypes.StringType, true, Metadata.empty()),
                new StructField("method", DataTypes.StringType, true, Metadata.empty()),
                new StructField("endpoint", DataTypes.StringType, true, Metadata.empty()),
                new StructField("protocol", DataTypes.StringType, true, Metadata.empty()),
                new StructField("response_code", DataTypes.StringType, true, Metadata.empty()),
                new StructField("content_size", DataTypes.StringType, true, Metadata.empty()),
                new StructField("referrer", DataTypes.StringType, true, Metadata.empty()),
                new StructField("browser", DataTypes.StringType, true, Metadata.empty()),
        };

        StructType structType = new StructType(structFields);

        DataFrame accesslogDF = sqlContext.createDataFrame(rdd,structType);

        accesslogDF.printSchema();
        accesslogDF.show(10);

        // TODO: Get the Count of those Access Logs entries which have the endpoint set to "/health"

        // TODO: Filter the source data to only get those Access Log entries with the host set to "10.236.133.247" and save the results to a Hive Table

    }

}