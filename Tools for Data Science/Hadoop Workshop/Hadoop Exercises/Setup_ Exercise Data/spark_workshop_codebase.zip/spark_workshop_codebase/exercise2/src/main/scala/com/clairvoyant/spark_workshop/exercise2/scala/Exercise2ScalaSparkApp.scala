package com.clairvoyant.spark_workshop.exercise2.scala

import java.util.regex.Pattern

import org.apache.spark.sql.Row
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.{SparkConf, SparkContext}


object Exercise2ScalaSparkApp {

  val PATH_TO_FILE = "/user/cloudera/spark_data/logs/access.log"

  val ACCESS_LOG_REGEX = "^(\\S+) (\\S+) (\\S+) \\[(\\S+ \\S+ \\S+ \\S+ \\S+ \\S+)\\] \"(\\S+)\\s?(\\S+)?\\s?(\\S+)?\" (\\d{3}|-) (\\d+|-)\\s?\"?([^\"]*)\"?\\s?\"?([^\"]*)?\"?$"

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("Exercise2ScalaSparkApp").setMaster("yarn-client")
    val sc = new SparkContext(conf)
    val sqlContext = new HiveContext(sc)

    val rawAccessLogDF = sqlContext.read.text(PATH_TO_FILE)

    val pattern = Pattern.compile(ACCESS_LOG_REGEX)

    val accessLogDF = rawAccessLogDF.map(row => {
      val entry = row.getAs[String](0)
      val matcher = pattern.matcher(entry)
      if(matcher.find()) {
        Row(matcher.group(1), matcher.group(2), matcher.group(3), matcher.group(4), matcher.group(5), matcher.group(6), matcher.group(7), matcher.group(8), matcher.group(9), matcher.group(10), matcher.group(11))
      } else {
        Row(null)
      }
    }).filter(row => row!=null)

    val schema = StructType(
      List(
        StructField("host", StringType, nullable = true),
        StructField("client_indentd", StringType, nullable = true),
        StructField("user_id", StringType, nullable = true),
        StructField("date_time", StringType, nullable = true),
        StructField("method", StringType, nullable = true),
        StructField("endpoint", StringType, nullable = true),
        StructField("protocol", StringType, nullable = true),
        StructField("response_code", StringType, nullable = true),
        StructField("content_size", StringType, nullable = true),
        StructField("referrer", StringType, nullable = true),
        StructField("browser", StringType, nullable = true)
      )
    )

    val accesslogDF = sqlContext.createDataFrame(accessLogDF, schema)

    accesslogDF.printSchema()
    accesslogDF.show(10)

    // TODO: Get the Count of those Access Logs entries which have the endpoint set to "/health"

    // TODO: Filter the source data to only get those Access Log entries with the host set to "10.236.133.247" and save the results to a Hive Table

  }

}