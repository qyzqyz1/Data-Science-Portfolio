__author__ = 'Clairvoyant'

from pyspark import SparkConf, SparkContext
from pyspark.sql import HiveContext
from pyspark.sql.types import *
import re
from pyspark.sql import Row


PATH_TO_FILE = "/user/cloudera/spark_data/logs/access.log"

ACCESS_LOG_REGEX= "^(\\S+) (\\S+) (\\S+) \\[(\\S+ \\S+ \\S+ \\S+ \\S+ \\S+)] \"(\\S+)\\s?(\\S+)?\\s?(\\S+)?\" (\\d{3}|-) (\\d+|-)\\s?\"?([^\"]*)\"?\\s?\"?([^\"]+)?\"?$"

if __name__ == "__main__":
    conf = SparkConf().setAppName("Exercise2PythonSparkApp").setMaster("yarn-client")
    sc = SparkContext(conf=conf)
    sqlContext = HiveContext(sc)

    raw_log_files = sc.textFile(PATH_TO_FILE)
    
    def parse_logs(logline):
        match = re.search(ACCESS_LOG_REGEX, logline)
        if match is None:
            return Row(None)
        else:
            return Row(match.group(1), match.group(2), match.group(3), match.group(4), match.group(5), match.group(6),
                       match.group(7), match.group(8), match.group(9), match.group(10), match.group(11))

    parsed_log_files = raw_log_files.map(parse_logs).filter(lambda row: row is not None)

    schema = StructType([
        StructField("host", StringType(), True),
        StructField("client_indentd", StringType(), True),
        StructField("user_id", StringType(), True),
        StructField("date_time", StringType(), True),
        StructField("method", StringType(), True),
        StructField("endpoint", StringType(), True),
        StructField("protocol", StringType(), True),
        StructField("response_code", StringType(), True),
        StructField("content_size", StringType(), True),
        StructField("referrer", StringType(), True),
        StructField("browser", StringType(), True)
    ])

    accesslogDF = sqlContext.createDataFrame(parsed_log_files, schema)
    accesslogDF.show(10)

    # TODO: Get the Count of those Access Logs entries which have the endpoint set to "/health"

    # TODO: Filter the source data to only get those Access Log entries with the host set to "10.236.133.247" and save the results to a Hive Table
