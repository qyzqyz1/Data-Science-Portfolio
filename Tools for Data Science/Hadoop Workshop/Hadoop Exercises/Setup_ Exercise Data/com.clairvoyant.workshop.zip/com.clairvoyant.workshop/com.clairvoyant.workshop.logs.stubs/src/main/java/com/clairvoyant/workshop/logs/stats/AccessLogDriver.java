package com.clairvoyant.workshop.logs.stats;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

/**
 * Assignment:
 * <p/>
 * In this exercise, you will process a webserver access log. You are to parse the URL out and count how many times it
 * was accessed. Some of the URL’s are REST service endpoints and start with /api. The final output should produce two
 * files, one for counts of REST URL hits and one for everything else. Further more, you should reduce the amount of data
 * going from the mapper to reducer where possible. Along with processing the data in the expected format, you are to track a
 * counter metric in your program called ‘UNDER_THRESHOLD’ which should count how many times the URL computed count was
 * less than 50.
 * <p/>
 * Process the data so you end up with output as:
 *      key -> URL
 *      Count -> count ow many times the URL was accessed.
 *  <p/>
 * Hint log lines come in different formats:
 *  1.  10.236.133.247 - - [Mon, 19 May 2014 16:29:31 GMT] \"POST /api/instrumentation/events/new HTTP/1.1\" 200 2 \"https://my.analytics.app/admin\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36"
 *  2.  10.236.133.247 - - [Mon, 19 May 2014 16:29:31 GMT] "GET /api/courses HTTP/1.1" 304 - "https://my.analytics.app/admin" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36"
 *  <p/>
 *
 */
public class AccessLogDriver extends Configured implements Tool {

    private static Logger LOGGER = Logger.getLogger(AccessLogDriver.class);

    public static void main(String[] args) throws Exception {
        execute(args, null, true);
    }

    public static void execute (String[] args, Configuration configuration, boolean exitOnEnd) throws Exception{
        if (configuration == null)
            configuration = new Configuration();
        int res = ToolRunner.run(configuration, new AccessLogDriver(), args);
        if (exitOnEnd)
            System.exit(res);
    }

    @Override
    public int run(String[] args) throws Exception {

        String inputDir = args[0];//input dir
        String outputDir = args[1];//output dir

        Job job = new Job(getConf());

        boolean del = FileSystem.get(job.getConfiguration()).delete(new Path(outputDir), true);
        if (del){
            LOGGER.info("Output directory existed and was deleted: " + outputDir);
        }

        FileInputFormat.addInputPath(job, new Path(inputDir));
        FileOutputFormat.setOutputPath(job, new Path(outputDir));

        job.setJarByClass(AccessLogDriver.class);

        job.setMapperClass(AccessLogMapper.class);
        job.setReducerClass(AccessLogReducer.class);

        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);

        //mapper
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);

        //reducer
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        //TODO: USE COMBINER WHERE APPROPRIATE

        //TODO: USE PARTITIONER WHERE APPROPRIATE

        return job.waitForCompletion(true) ? 0 : 1;
    }
}
