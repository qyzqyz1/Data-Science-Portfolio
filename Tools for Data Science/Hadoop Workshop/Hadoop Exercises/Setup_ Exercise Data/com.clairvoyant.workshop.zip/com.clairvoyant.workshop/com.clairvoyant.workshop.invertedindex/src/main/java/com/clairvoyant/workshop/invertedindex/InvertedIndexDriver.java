package com.clairvoyant.workshop.invertedindex;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 * Demonstration: Creating an InvertedIndex for a book
 *
 * Inverted Index for a book is the index that we see at the end of book. For every word in the book we have a list of page numbers where that word is present.
 * Provides a way to look up of all the pages where a word has been used/referred.
 *  
 * Input: Let us assume that we have a bunch of text files where each file has the contents of one page of the book. Lets also assume that the name of the file is the 
 *        page number of the book.
 *        Input files are available in the folder sample-data/input/invertedIndex
 * 
 * Output: We need an output similar to 
 * 		AARON	37,
		ABATE	12,
		ABATEMENT	12,
		ABERGAVENNY	16,
		...
		...
		...
        zephyrs	11,
		zodiac	37,
        zodiacs	24,
 *
 * Excercises the usage of HDFS commands, running a mapReduce job and  verifying the output
 *
 */

public class InvertedIndexDriver extends Configured implements Tool {

	public static void main(String args[]) throws Exception {

		//args = new String[] { "/user/invertedindex/input/", "/user/invertedindex/output/" };
		execute(args, null, true);
	}

	public static void execute(String[] args, Configuration configuration, boolean exitOnEnd) throws Exception {
		if (configuration == null)
			configuration = new Configuration();
		int res = ToolRunner.run(configuration, new InvertedIndexDriver(), args);
		if (exitOnEnd)
			System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {
		/* 
		 * Instantiate a Job object for your job's configuration.
		 */
		Job job = new Job();

		job.setJarByClass(InvertedIndexDriver.class);

		/*
		 * Specify an easily-decipherable name for the job. This job name will
		 * appear in reports and logs.
		 */
		job.setJobName("InvertedIndexDriver");

		/*
		 * Specify the paths to the input and output data based on the
		 * command-line arguments.
		 */
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		/*
		 * Specify the mapper and reducer classes.
		 */
		job.setMapperClass(InvertedIndexMapper.class);
		job.setReducerClass(InvertedIndexReducer.class);
		job.setNumReduceTasks(1);

		/*
		 * Specify the job's output key and value classes.
		 */
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		/*
		 * Start the MapReduce job and wait for it to finish. If it finishes
		 * successfully, return 0. If not, return 1.
		 */
		boolean success = job.waitForCompletion(true);
		return success ? 0 : 1;
	}
}
