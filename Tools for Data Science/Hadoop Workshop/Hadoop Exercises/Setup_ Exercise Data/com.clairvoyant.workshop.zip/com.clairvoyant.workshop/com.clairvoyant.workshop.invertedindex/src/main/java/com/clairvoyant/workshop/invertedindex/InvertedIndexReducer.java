package com.clairvoyant.workshop.invertedindex;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class InvertedIndexReducer extends Reducer<Text, Text, Text, Text> {

	@Override
	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

		StringBuilder reverseIndex = new StringBuilder();
		Set<String> uniqueStr = new HashSet<String>();

		/*
		 * For each value in the set of values passed to us by the mapper:
		 */
		for (Text value : values) {
			uniqueStr.add(value.toString());
		}

		for (String str : uniqueStr) {
			reverseIndex.append(str);
			reverseIndex.append(",");
		}

		/*
		 * Call the write method on the Context object to emit a key and a value
		 * from the reduce method.
		 */
		context.write(key, new Text(reverseIndex.toString()));
	}
}
