

create table movies(id int, title String, releaseDate timestamp,videoReleaseDate timestamp ,IMDBurl String, unknown String,isAction boolean, isAdventure boolean, isAnimation boolean,
                   isChildren boolean,isComedy boolean,isCrime boolean,isDocumentary boolean,isDrama boolean,isFantash boolean,isFilmNoir boolean, isHorror boolean,isMusical boolean,
                   isMystery boolean, isRomance boolean, isSciFi boolean, isThriller boolean,isWar boolean, isWestern boolean)


row format delimited fields terminated by '|' stored as textfile;


LOAD DATA INPATH ‘/path/on/hdfs/file_name.csv’ OVERWRITE INTO TABLE example1;


LOAD DATA INPATH '/user/cloudera/workshop/hive/movies/movies.txt' OVERWRITE INTO TABLE movies;


CREATE EXTERNAL TABLE IF NOT EXISTS access_log (
  log_line STRING
)
PARTITIONED BY (hive_entry_timestamp STRING)
ROW FORMAT DELIMITED
    FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/user/clairvoyant/workshop/access_logs';

-- =====================================================================================================================

ALTER TABLE access_log
  DROP IF EXISTS PARTITION (hive_entry_timestamp='2014-07-04T00:00Z');

ALTER TABLE access_log
  ADD PARTITION (hive_entry_timestamp='2014-07-04T00:00Z')
  LOCATION '/user/clairvoyant/workshop/access_logs/2014/07/04/00/00';

-- =====================================================================================================================

CREATE EXTERNAL TABLE IF NOT EXISTS parsed_access_log (
  log_date STRING,
  ip STRING,
  http_method STRING,
  uri STRING,
  protocol STRING,
  user_agent STRING,
  url STRING
)
PARTITIONED BY (hive_entry_timestamp STRING)
ROW FORMAT DELIMITED
    FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/user/clairvoyant/workshop/parsed_access_log';

-- =====================================================================================================================


ALTER TABLE parsed_access_log
  DROP IF EXISTS PARTITION (hive_entry_timestamp='2014-07-04T00:00Z');

ALTER TABLE parsed_access_log
  ADD PARTITION (hive_entry_timestamp='2014-07-04T00:00Z')
  LOCATION '/user/clairvoyant/workshop/parsed_access_log/2014/07/04/00/00';

INSERT OVERWRITE DIRECTORY '/user/clairvoyant/workshop/parsed_access_log/2014/07/04/00/00'

-- 10.236.133.247 - - [Mon, 19 May 2014 16:31:13 GMT] "GET /api/admin/job/aggregator/status HTTP/1.1" 200 1534 "https://my.analytics.app/admin" "" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36"

SELECT
  TRIM(SUBSTRING( log_line, INSTR(log_line, "[")+1, INSTR(log_line, "]")-(INSTR(log_line, "[")+1) )) AS log_date,
  TRIM(SUBSTRING( log_line, 0, INSTR(log_line, "-")-2) ) AS ip,

  SPLIT(TRIM(SUBSTRING( log_line, (INSTR(log_line, " \"")+2), INSTR(log_line, " \"") ) ), " ")[0] AS method,
  SPLIT(TRIM(SUBSTRING( log_line, (INSTR(log_line, " \"")+2), INSTR(log_line, " \"") ) ), " ")[1] AS uri,
  REGEXP_REPLACE(SPLIT(TRIM(SUBSTRING( log_line, (INSTR(log_line, " \"")+2), INSTR(log_line, " \"") ) ), " ")[2], "\"", "") AS proto,

  TRIM(SUBSTRING(log_line, (instr(log_line, "\" \"")+3), ( (length(log_line)-1)) - (INSTR(log_line, "\" \"")+2) )) AS user_agent,

  CASE
    WHEN INSTR(log_line, "\"http") > 0
      THEN TRIM(SUBSTRING( log_line, (INSTR(log_line, "\"http")+1), INSTR(log_line, "\" \"") - (INSTR(log_line, "\"http")+1) ) )
    ELSE "N/A"
  END AS url
FROM access_log
WHERE hive_entry_timestamp = '2014-07-04T00:00Z';

