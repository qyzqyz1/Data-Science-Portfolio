package com.clairvoyant.workshop.logs.stats;

import com.clairvoyant.workshop.logs.domain.AccessLog;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;


public class AccessLogMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
    }

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        AccessLog accessLog = AccessLog.parse(value.toString());
        //context.write(new Text(accessLog.getIp()), new IntWritable(1));
        context.write(new Text(accessLog.getUri()), new IntWritable(1));
    }

}