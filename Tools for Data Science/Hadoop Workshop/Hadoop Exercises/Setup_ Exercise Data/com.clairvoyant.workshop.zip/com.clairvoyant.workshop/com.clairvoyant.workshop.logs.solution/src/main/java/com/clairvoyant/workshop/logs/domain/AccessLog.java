package com.clairvoyant.workshop.logs.domain;


/**
 * Sample log line: 10.236.133.247 - - [Mon, 19 May 2014 16:29:29 GMT] "GET /admin HTTP/1.1" 304 - "https://my.analytics.app/admin" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36"
 *
 */

public class AccessLog {

    private String ip;
    private String date;
    private String method;
    private String uri;
    private String protocol;
    private int status;
    private String url;
    private String userAgent;

    public AccessLog() {
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public static AccessLog parse(String line){
        //10.236.133.247 - - [Mon, 19 May 2014 16:29:29 GMT] "GET /admin HTTP/1.1" 304 - "https://my.analytics.app/admin" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36"
        String ip = line.substring(0, line.indexOf("-")).trim();
        String date = line.substring(line.indexOf("[")+1, line.indexOf("]"));

        //        String line = "10.236.133.247 - - [Mon, 19 May 2014 16:29:31 GMT] \"POST /api/instrumentation/events/new HTTP/1.1\" 200 2 \"https://my.analytics.app/admin" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36\"";

        String url = "NA";
        if (line.contains("http")){
            url = line.substring(line.indexOf("http"), line.indexOf("\" \""));
        }

        String meta[] = line.substring(line.indexOf(" \""), line.indexOf("\" ")).trim().split(" ");
        String method = meta[0].replaceAll("\"", "");
        String uri = meta[1];
        String proto = meta[2];
        String userAgent = line.substring(line.indexOf("\" \"") + "\" \"".length(), line.length()-1);
        String status = line.substring(line.indexOf("\" ")+2, line.indexOf("\" ")+5);

        AccessLog accessLog = new AccessLog();
        accessLog.setStatus(Integer.parseInt(status));
        accessLog.setDate(date);
        accessLog.setIp(ip);
        accessLog.setMethod(method);
        accessLog.setUri(uri);
        accessLog.setProtocol(proto);
        accessLog.setUserAgent(userAgent);
        accessLog.setUrl(url);

        return accessLog;
    }

}
