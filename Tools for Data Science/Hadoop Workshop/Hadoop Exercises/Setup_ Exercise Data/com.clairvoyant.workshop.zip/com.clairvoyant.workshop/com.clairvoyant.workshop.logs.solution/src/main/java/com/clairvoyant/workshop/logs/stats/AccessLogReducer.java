package com.clairvoyant.workshop.logs.stats;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class AccessLogReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

    private static final int THRESHOLD = 50;

    public enum Counter{
        UNDER_THRESHOLD;
    }

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {

        int count = 0;
        for (IntWritable intWritable: values){
            count+= intWritable.get();
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //counter
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        if(count < THRESHOLD)
            context.getCounter(Counter.UNDER_THRESHOLD).increment(1);

        context.write(key, new IntWritable(count));
    }

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
