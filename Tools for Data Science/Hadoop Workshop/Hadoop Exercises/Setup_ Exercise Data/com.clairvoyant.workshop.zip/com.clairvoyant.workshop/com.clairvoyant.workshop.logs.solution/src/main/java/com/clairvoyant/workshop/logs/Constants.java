package com.clairvoyant.workshop.logs;

/**
 * Created with IntelliJ IDEA.
 * User: mansari
 * Date: 7/22/14
 * Time: 11:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class Constants {

    public static final String LOG_INPUT = "/Users/mansari/development/svn/com.clairvoyant.workshop/data/input/logs/access.log";
    public static final String STATS_OUTPUT = "/Users/mansari/development/svn/com.clairvoyant.workshop/data/output/logs/stats/";
    public static final String FLATTEN_OUTPUT = "/Users/mansari/development/svn/com.clairvoyant.workshop/data/output/logs/flatten/";

}
