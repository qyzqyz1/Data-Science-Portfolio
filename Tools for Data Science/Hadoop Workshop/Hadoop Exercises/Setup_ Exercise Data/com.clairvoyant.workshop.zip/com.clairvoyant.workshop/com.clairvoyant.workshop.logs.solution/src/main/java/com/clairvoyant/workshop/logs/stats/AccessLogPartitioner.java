package com.clairvoyant.workshop.logs.stats;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;


/**
 * Partitions data into two files, one for access log entries for "/api" endpoints, and other for everything else
 */
public class AccessLogPartitioner extends Partitioner<Text, IntWritable> {

    public AccessLogPartitioner() {
    }

    @Override
    public int getPartition(Text key, IntWritable value, int numReduceTasks) {
        //this is done to avoid performing mod with 0
        if(numReduceTasks == 0)
            return 0;
        else if (key.toString().contains("/api")){
            return 0;
        }
        else{
            return 1;
        }
    }
}
