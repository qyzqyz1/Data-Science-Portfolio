package com.clairvoyant.workshop.logs.flatten;

import com.clairvoyant.workshop.logs.domain.AccessLog;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

public class AccessLogFlattenMapper extends Mapper<LongWritable, Text, NullWritable, Text> {

    private static final String DELIMITER = "\t";

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);    //To change body of overridden methods use File | Settings | File Templates.
    }

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        AccessLog accessLog = AccessLog.parse(value.toString());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(accessLog.getDate())
                .append(DELIMITER)
                .append(accessLog.getIp())
                .append(DELIMITER)
                .append(accessLog.getUrl())
                .append(DELIMITER)
                .append(accessLog.getMethod())
                .append(DELIMITER)
                .append(accessLog.getUri())
                .append(DELIMITER)
                .append(accessLog.getProtocol())
                .append(DELIMITER)
                .append(accessLog.getUserAgent());

        context.write(NullWritable.get(), new Text(stringBuilder.toString()));
    }
}

