package com.clairvoyant.workshop.logs.flatten;

import com.clairvoyant.workshop.logs.Constants;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

/**
 * Assignment:
 * <p/>
 * Access logs are produced by Webservers and give information on the endpoint/URL which was accessed.
 * Log processing was one of the early Hadoop use cases to be used in enterprise. Access logs can be useful
 * to determine the most accessed URL, which URL causes 5XX statuses, and what the user-agent (client meta data) of the
 * client is. To make it simple to get many such insights, its is often better to first process the unstructured logs
 * into a more structured form.
 * <p/>
 * In this exercise we will take a log line, extract fields or columns, and create a fixed column tab delimited CSV.
 * <p/>
 * Process the data so you end up with output as:
 *  key: NULL
 *  value as tab delimited rows:
 *      date
 *      ip,
 *      url,
 *      method,
 *      uri,
 *      protocol,
 *      user_agent
 * <p/>
 * Sample output row will look like:
 *   Mon, 19 May 2014 16:29:29 GMT	10.236.133.247	https://my.analytics.app/admin	GET	/admin	HTTP/1.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36
 * <p/>
 * Hint log lines come in different formats:
 * <p/>
 *  1.  10.236.133.247 - - [Mon, 19 May 2014 16:29:31 GMT] \"POST /api/instrumentation/events/new HTTP/1.1\" 200 2 \"https://my.analytics.app/admin\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36"
 *  2.  10.236.133.247 - - [Mon, 19 May 2014 16:29:31 GMT] "GET /api/courses HTTP/1.1" 304 - "https://my.analytics.app/admin" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36"
 */
public class AccessLogFlattenDriver extends Configured implements Tool {

    private static Logger LOGGER = Logger.getLogger(AccessLogFlattenDriver.class);

    public static void main(String[] args) throws Exception {
        if (args == null || args.length == 0){
            args = new String[]{
                    Constants.LOG_INPUT,
                    Constants.FLATTEN_OUTPUT
            };
        }
        execute(args, null, true);
    }

    public static void execute (String[] args, Configuration configuration, boolean exitOnEnd) throws Exception{
        if (configuration == null)
            configuration = new Configuration();
        int res = ToolRunner.run(configuration, new AccessLogFlattenDriver(), args);
        if (exitOnEnd)
            System.exit(res);
    }

    @Override
    public int run(String[] args) throws Exception {

        String inputDir = args[0];//input dir
        String outputDir = args[1];//output dir

        String jobName =  "access-log-parser";

        Job job = new Job(getConf(), jobName);

        boolean del = FileSystem.get(job.getConfiguration()).delete(new Path(outputDir), true);
        if (del){
            LOGGER.info("Output directory existed and was deleted: " + outputDir);
        }

        FileInputFormat.addInputPath(job, new Path(inputDir));
        FileOutputFormat.setOutputPath(job, new Path(outputDir));

        job.setJarByClass(AccessLogFlattenDriver.class);

        job.setMapperClass(AccessLogFlattenMapper.class);

        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);

        //mapper
        job.setMapOutputKeyClass(NullWritable.class);
        job.setMapOutputValueClass(Text.class);

        //note: no reducer needed

        LOGGER.info("Starting job: " + jobName);

        return job.waitForCompletion(true) ? 0 : 1;
    }
}
