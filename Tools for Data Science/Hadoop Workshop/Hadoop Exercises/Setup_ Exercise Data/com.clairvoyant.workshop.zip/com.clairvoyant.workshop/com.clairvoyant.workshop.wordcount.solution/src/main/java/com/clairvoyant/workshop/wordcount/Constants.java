package com.clairvoyant.workshop.wordcount;

/**
 * Created by cloudera on 10/12/14.
 */
public class Constants {

    public static final String WORDCOUNT_INPUT = "/home/cloudera/Downloads/com.clairvoyant.workshop/data/input/wordcount/";
    public static final String WORDCOUNT_OUTPUT = "/Users/mansari/development/svn/com.clairvoyant.workshop/data/input/baseball/Master.csv";
   }
