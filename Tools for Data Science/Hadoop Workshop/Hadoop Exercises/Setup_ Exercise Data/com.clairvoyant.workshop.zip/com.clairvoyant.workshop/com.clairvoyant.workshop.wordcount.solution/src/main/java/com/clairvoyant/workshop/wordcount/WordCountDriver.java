package com.clairvoyant.workshop.wordcount;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

/**
 * Created by cloudera on 10/12/14.
 */
public class WordCountDriver extends Configured implements Tool {

    private static Logger LOGGER = Logger.getLogger(WordCountDriver.class);

    public static void main(String[] args) throws Exception {
        execute(args, null, true);
    }

    public static void execute(String[] args, Configuration configuration, boolean exitOnEnd) throws Exception {
        if (configuration == null)
            configuration = new Configuration();
        int res = ToolRunner.run(configuration, new WordCountDriver(), args);
        if (exitOnEnd)
            System.exit(res);
    }

    @Override
    public int run(String[] args) throws Exception {

        String inputDir = args[0];//input dir
        String outputDir = args[1];//output dir

        Job job = new Job(getConf());

        boolean del = FileSystem.get(job.getConfiguration()).delete(new Path(outputDir), true);
        if (del) {
            LOGGER.info("Output directory existed and was deleted: " + outputDir);
        }

        FileInputFormat.addInputPath(job, new Path(inputDir));
        FileOutputFormat.setOutputPath(job, new Path(outputDir));

        job.setJarByClass(WordCountDriver.class);

        job.setMapperClass(WordCountMapper.class);
        job.setReducerClass(WordCountReducer.class);

        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        //reducer
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        //TODO: USE COMBINER WHERE APPROPRIATE

        //TODO: USE PARTITIONER WHERE APPROPRIATE

        return job.waitForCompletion(true) ? 0 : 1;
    }
}
